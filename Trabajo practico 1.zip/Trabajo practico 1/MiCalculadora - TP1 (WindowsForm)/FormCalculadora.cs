﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiCalculadora___TP1__WindowsForm_
{
    public partial class LaCalculadora : Form
    {
        public LaCalculadora()
        {
            InitializeComponent();           
                        
        }


        public static double Operar(Numero num1,Numero num2, string operador)
        {
            double resultado=0;

            if (operador == "-" || operador == "+" || operador == "*" || operador == "/")
            {
                
                //double numero1 = double.Parse(num1);
                //double numero2 = double.Parse(num2);
                switch (operador)
                {
                    case "+":
                        resultado = num1 + num2;
                        break;
                    case "-":
                        resultado = num1 - num2;
                        break;
                    case "*":
                        resultado = num1 * num2;
                        break;
                    case "/":                        
                        resultado = num1 / num2;
                        break;
                }
                
            }
            return resultado;
        }        

        private void btnOperar_Click(object sender, EventArgs e)
        {   
            if(textBox1.Text == "" || textBox2.Text == "")
            {
                textBox1.Clear();
                textBox2.Clear();
                MessageBox.Show("Ingrese datos en los dos campos");
            }
            else
            {   
                if (Numero.ValidarNumero(textBox1.Text) == -1 || Numero.ValidarNumero(textBox2.Text) == -1) 
                {
                    MessageBox.Show("El dato ingresado NO es un numero");
                    textBox1.Clear();
                    textBox2.Clear();                
                }
            else
            {
                double resultado = 0;
                
                resultado = Operar(textBox1.Text, textBox2.Text, comboBox1.Text); //Guardo el double que devuelve Operar(num1,num2,operacion)
                resultado = Math.Round(resultado, 2);  //Muestro dos decimales                
                label1.Text = Convert.ToString(resultado); 
                
            }

            }           
            
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            Limpiar();            
        }      
                
        private void btnConvertirABinario_Click(object sender, EventArgs e)
        {
            if (label1.Text == "")
            {
                MessageBox.Show("Primero debe hacer una operacion");
                textBox2.Clear();
                textBox1.Clear();

            }
            else
            {
                if(int.Parse(label1.Text) < 0)
                {
                    label1.Text = "Valor invalido";
                }
                else
                {
                label1.Text = Numero.DecimalToBinario(double.Parse(label1.Text));
                }               
                
            }
            

        }

        private void btnConvertirADecimal_Click(object sender, EventArgs e)
        {
            
            if (label1.Text == "")
            {
                MessageBox.Show("Primero debe hacer una operacion");
                textBox2.Clear();
                textBox1.Clear();

            }
            else
            {       if(Numero.BinarioToDecimal(label1.Text) == "Valor invalido")
                {
                    label1.Text = Numero.BinarioToDecimal(label1.Text);
                }
                else
                {
                    string numeroDecimal = Numero.BinarioToDecimal(label1.Text);
                    label1.Text = numeroDecimal;
                }            
                                                    
            }

        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Close();
        }                   
         
        private void Limpiar()
        {
            this.textBox1.Clear();
            this.textBox2.Clear();
            this.comboBox1.Text = "";            
            this.label1.Text = "";
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void splitter1_SplitterMoved(object sender, SplitterEventArgs e)
        {

        }        

        private void FormCalculadora_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private static double Operar(string n1, string n2, string operador)
        {
            return LaCalculadora.Operar(new Numero(n1), new Numero(n2), operador);
        }
    }
}
