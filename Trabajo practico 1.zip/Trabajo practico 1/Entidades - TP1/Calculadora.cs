﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades___TP1
{
    
        static class Calculadora
        {
            private static string ValidarOperador(string operador) //El método ValidarOperador será privado y estático. Deberá validar que el operador
                                                                   //recibido sea +, -, / o*. Caso contrario retornará +.
            {
            string operacionPedida="";

                if (operador == "*" || operador == "/" || operador == "+" || operador == "-")
                {
                switch (operador)
                {
                    case "+":
                        operacionPedida = "suma";
                        break;
                    case "-":
                        operacionPedida = "resta";
                        break;
                    case "*":
                        operacionPedida = "multiplicacion";
                        break;
                    case "/":
                        operacionPedida = "division";
                        break;
                    default:
                        Console.WriteLine("Error, elija una operacion correcta");
                        break;
                }
               
               
                
                }
            else
            {
                operacionPedida = "+";
            }
            return operacionPedida;
           }

            public static double Operar(int numero1, int numero2, string operador)
            {
            string operacionPedida=ValidarOperador(operador);
                 if(operacionPedida == "+")
            {
                Console.WriteLine("Error, ingrese un operador existente ( '+' '-' '*' '/')");
            }               

                
                double resultado = 0;
                switch (operacionPedida)
                {
                    case "suma":
                        resultado = numero1 + numero2;
                        break;
                    case "resta":
                        resultado = numero1 - numero2;
                        break;
                    case "multiplicacion":
                        resultado = numero1 * numero2;
                        break;
                    case "division":
                        if(numero2 == 0)
                    {
                        Console.WriteLine("Error, no se puede dividir por cero");
                    }
                    else
                    {
                        resultado = (numero1 / numero2);
                    }
                        
                        break;
                    default:
                        break;

                }
                return resultado;
            }



        }
    
}
