﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades___TP1
{
    class Program
    {
        static void Main(string[] args)
        {
            double resultado;
            Numero num1 = new Numero();            

            /*Console.WriteLine("\n**Escriba el signo correspondiente a su operacion**\n\n");
            Console.Write("Sumar = (+)\nRestar = (-)\nMultiplicar = (*)\nDividir = (/)\n\nOpcion:");*/

            resultado = Calculadora.Operar(100,-2,"+");
            Console.WriteLine("resultado: " + resultado); 

            //Console.WriteLine("Binario :"+ num1.BinarioDecimal("1101"));
            



                        

            Console.ReadKey();
        }
    }
}
