﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiCalculadora___TP1__WindowsForm_
{
    public class Numero
    {
        private double num1;

        public string SetNumero
        {
            set
            {
                num1 = ValidarNumero(value);
            }           
        }

        public Numero(double nume)
        {
            SetNumero = nume.ToString();
        }

        public Numero(string strNumero)
        {
            SetNumero = strNumero;
        }

        public static string BinarioToDecimal(string numero)
        {   
            char[] array = numero.ToCharArray();
            // Invertido pues los valores van incrementandose de derecha a izquierda: 16-8-4-2-1
            Array.Reverse(array);
            int sum = 0;

            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] == '0' || array[i] == '1')
                {
                    if (array[i] == '1')
                    {
                        // Usamos la potencia de 2, según la posición
                        sum += (int)Math.Pow(2, i);
                    }
                }
                else
                {
                    return "Valor invalido";
                }

            }
            return Convert.ToString(sum);

        }

        public static string DecimalToBinario(double numero)
        {
            String cadena = "";
            if (numero > 0)
            {

                while (numero > 0)
                {
                    if (numero % 2 == 0)
                    {
                        cadena = "0" + cadena;
                    }
                    else
                    {
                        cadena = "1" + cadena;
                    }
                    numero = (int)(numero / 2);
                }

            }
            else
            {
                if (numero == 0)
                {
                    Console.WriteLine("0");
                }
                else
                {
                    Console.WriteLine("Ingrese solo numeros positivos");
                }
            }


            return cadena;
        }

        static bool esBinario(string numero)
        {
            char[] palabra = numero.ToCharArray();
            for (int i = 0; i < numero.Length; i++)
            {
                if (palabra[i] == '1' || palabra[i] == '0')
                {
                    return false;
                }
            }
            return true;
        }

        public static double ValidarNumero(string strNumero)
        {            
            bool esNumero;
            double SiEsNumero;

            esNumero = double.TryParse(strNumero, out SiEsNumero); ///Verifico con BOOL si el string recibido es un numero, la referencia out me dice si es un numero

            if (!esNumero)
            {
                

                return -1;
            }


            return SiEsNumero;

        }

        public static double operator +(Numero n1, Numero n2)
        {
            double retorno;
            retorno = n1.num1 + n2.num1;
            return retorno;
        }

        public static double operator -(Numero n1, Numero n2)
        {
            double retorno;
            retorno = n1.num1 - n2.num1;
            return retorno;
        }

        public static double operator *(Numero n1, Numero n2)
        {
            double retorno;
            retorno = n1.num1 * n2.num1;
            return retorno;
        }

        public static double operator /(Numero n1, Numero n2)
        {
            double retorno;
            if(n1.num1 == 0 || n2.num1 == 0)
            {
                retorno = Double.MinValue;
            }
            retorno = n1.num1 / n2.num1;
            return retorno;
        }


    }
}
