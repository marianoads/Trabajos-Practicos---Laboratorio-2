﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades___TP1
{
    class Numero
    {
        private double numero1 = 0;

        public string DecimalBinario(string numero)
        {
            String cadena = "";
            if (ValidarNumero(numero) == 0)            //Valido que se ingresen SOLO numeros
            {
                Console.WriteLine("Error, ingrese solo numeros!!");
            }
            else
            {
                if(Convert.ToInt32(numero) < 0)        //Valido que el numero sea POSITIVO
                {
                    Console.WriteLine("Error, ingrese solo numeros positivos");
                }
                else
                {
                    int numeroInt;
                    numeroInt = Convert.ToInt32(numero);
                    if (numeroInt > 0)
                    {

                        while (numeroInt > 0)
                        {
                            if (numeroInt % 2 == 0)
                            {
                                cadena = "0" + cadena;
                            }
                            else
                            {
                                cadena = "1" + cadena;
                            }
                            numeroInt = (int)(numeroInt / 2);
                        }

                    }
                    else
                    {
                        if (numeroInt == 0)
                        {
                            Console.WriteLine("0");
                        }
                        else
                        {
                            Console.WriteLine("Ingrese solo numeros positivos");
                        }
                    }
                }
                
                
            }

            return cadena;


        }

        public string DecimalBinario(double numero)
        {
            String cadena = "";
            if (numero > 0)
            {

                while (numero > 0)
                {
                    if (numero % 2 == 0)
                    {
                        cadena = "0" + cadena;
                    }
                    else
                    {
                        cadena = "1" + cadena;
                    }
                    numero = (int)(numero / 2);
                }

            }
            else
            {
                if (numero == 0)
                {
                    Console.WriteLine("0");
                }
                else
                {
                    Console.WriteLine("Ingrese solo numeros positivos");
                }
            }


            return cadena;
        }

        private bool VerificarSiEsBinario(string binario)
        {
            char[] array = binario.ToCharArray();
            for(int i = 0; i < binario.Length; i++)
            {
                if(array[i] != '0' && array[i] != '1')
                {
                    return false;
                }

                
            }
            return true;
        }


        public string BinarioDecimal(string numero)
        {
            int sum = 0;
            if (ValidarNumero(numero) == 0)
            {
                Console.WriteLine("Error, ingrese solo numeros!!");
            }
            else
            {               
            if (VerificarSiEsBinario(numero))
            {
            char[] array = numero.ToCharArray();
            // Invertido pues los valores van incrementandose de derecha a izquierda: 16-8-4-2-1
            Array.Reverse(array);
            

            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] == '1')
                {
                    // Usamos la potencia de 2, según la posición
                    sum += (int)Math.Pow(2, i);
                }
            }            
            }
            else
            {
                Console.WriteLine("VALOR INVALIDO, ingrese solos 0 o 1");
            }
        }          


            return Convert.ToString(sum); // Convierto entero a string y lo retorno
        }

        public void SetNumero(string numero)
        {
            if (ValidarNumero(numero) == 0)
            {
                Console.WriteLine("Error, el dato ingresado NO es un numero");
            }
            else
            {
                this.numero1 = double.Parse(numero);
                Console.WriteLine("El numero se guardo correctamente ");
            }

        }

        public static double ValidarNumero(string strNumero)
        {
            bool esNumero;
            double SiEsNumero;

            esNumero = double.TryParse(strNumero, out SiEsNumero); ///Verifico con BOOL si el string recibido es un numero, la referencia out me dice si es un numero

            if (!esNumero)
            {
                //Console.WriteLine("El dato ingresado NO es un numero");
               return 0;
            }            

            //Console.WriteLine("El valor ingresado es :"+ strNumero);
            return SiEsNumero;

        }


    }
}
